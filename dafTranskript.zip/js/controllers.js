angular.module('app.controllers', [])
  
.controller('dAFKOMPAKTA1Ctrl', function($scope) {

})
    